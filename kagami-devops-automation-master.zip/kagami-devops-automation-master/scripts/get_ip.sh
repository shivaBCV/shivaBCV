#!/bin/bash
terraform output ip | grep -Ev "[|]" | awk 'BEGIN {FS="\""}{print $2}' > /tmp/public_ip.txt