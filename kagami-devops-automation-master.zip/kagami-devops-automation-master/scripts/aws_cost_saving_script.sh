#!/bin/bash
set -x
AWS_CLI='/usr/bin/aws ec2'
DATE=`date +%Y-%m-%d`
LOGDIR="/var/lib/jenkins/nightsleep"
LOG_START_INST=$LOGDIR/startlog.$DATE
LOG_STOP_INST=$LOGDIR/stoplog.$DATE

if [ ! -d $LOGDIR ] ; then
	mkdir -p $LOGDIR
	chmod 700 $LOGDIR
fi

rm -f instance_id.txt

COLLECT_INSTANCES () {
for i in  `echo $ListofMachines | tr "," "\n"`;
	do
		instance_id=`aws ec2 describe-instances --filters "Name=tag:Name,Values=$i" | grep InstanceId | awk 'BEGIN {FS="\""}{print $4}'`
        echo $instance_id >> instance_id.txt
    done
}

# calling COLLECT_INSTANCES to get all the instances
COLLECT_INSTANCES

INSTANCE_START () {

	for INSTANCE_ID in `cat instance_id.txt`; do
		echo "##### Working on Instance startup :  $INSTANCE_ID ####" | cowsay | tee -a $LOG_START_INST
		$AWS_CLI start-instances --instance-id $INSTANCE_ID | cowsay | tee -a $LOG_START_INST
	done
}
 INSTANCE_STOP () {
	
	for INSTANCE_ID in `cat instance_id.txt`; do
		echo "##### Working on Instance stop  : $INSTANCE_ID #### " | cowsay | tee -a $LOG_STOP_INST 
		$AWS_CLI stop-instances --instance-id $INSTANCE_ID | cowsay | tee -a $LOG_STOP_INST
	done
}
 INSTANCE_STATUS () {
	
	for INSTANCE_ID in `cat instance_id.txt`; do
    echo "##### Working on Instance status checking :  $INSTANCE_ID #### " 
	INSTANCE_STATE=`aws ec2 describe-instances --instance-id $INSTANCE_ID --output text | grep -w STATE | awk '{print $NF}'`
	echo "Instance $INSTANCE_ID is under Night Sleep and its current state is : $INSTANCE_STATE" | cowsay
	done
}

OPTION=${Action}
case $OPTION in 
	start)  INSTANCE_START ;;
	stop)   INSTANCE_STOP ;;
	status) INSTANCE_STATUS ;;
	*)      echo "Error occoured : vaild options are start/stop/status" | cowsay ;;
esac
