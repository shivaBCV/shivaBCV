
#!/bin/bash

#This script checks if KGM Golden AMI is available or not and is called inside deploy-customer-instance.jenkinsfile pipeline

if [ -s /home/ubuntu/devops/jenkins_share/kgm-golden-ami ];then
    golden_ami=`cat /home/ubuntu/devops/jenkins_share/kgm-golden-ami`
    echo "$golden_ami is available and will be used for customer instance"
else
    echo "No golden ami available and hence exiting"
    exit 2
fi