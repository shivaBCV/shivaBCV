#!/bin/bash
DATE=`date +%d-%m-%Y`
today=`date +"%d-%m-%Y-%H%M"`
date=`date`
mysql_username=produser
mysql_password=prod@kagamierp
message="Seems you are confused. Either select FullDB (which will restore entier DB) or mention TableName (If only single table needs to be restored or Select OnlyProcedure (if you want to restore only procedures). Hence failing this job"

db_requirement_check () {
    if [ ${SourceDatabase} = "_kagamierp" ] || [ ${DestinationDatabase} = "_kagamierp" ] || [ -z ${SourceDatabase} ] || [ -z ${DestinationDatabase} ];then
        echo "Condition 1 (db_requirement_check): Please mention correct source and destination database name. Failing this job" | cowsay
        exit 1
    else
        if [ ${LiveDB} = "true" ]; then
            ansible ${SourceMachine} -m shell -a "mysql -u${mysql_username} -p${mysql_password} -e 'show databases;' | grep ${SourceDatabase}"
            if [ `echo $?` -eq 0 ];then
                echo "${SourceDatabase} database found on ${SourceMachine} and hence proceeding further" | cowsay
            else
            echo "${SourceDatabase} database not found on ${SourceMachine}" | cowsay
            exit 1
            fi
        elif [ ${LiveDB} = "false" ];then
            aws s3 ls s3://${SourceMachine}-mysql-backup/${SourceDatabase} | sort | tail -n 1 | awk '{print $NF}'
            if [ `echo $?` -eq 0 ];then
                echo "${SourceDatabase} database dump found in S3 and hence proceeding further" | cowsay
            else
            echo "${SourceDatabase} database dump not found in S3" | cowsay
            exit 1
            fi
        fi
    fi
    }

# Calling db_requirement_check function
db_requirement_check

# This function will check if the restoration of Database or Table or Procedures are done successfully or not
db_restoration_check () {
    if [ `echo $?` -eq 0 ];then
        if [ ${FullDB} = "true" ];then
            echo "${SourceDatabase} database from ${SourceMachine} restored on ${DestinationMachine} in ${DestinationDatabase} database" | cowsay
        elif [ ! -z ${TableName} ]; then
            echo "${TableName} table from ${SourceMachine} restored on ${DestinationMachine} in ${DestinationDatabase} database" | cowsay
        elif [ ${OnlyProcedure} = "true" ];then
            echo "Procedures from ${SourceMachine} restored on ${DestinationMachine} in ${DestinationDatabase} database" | cowsay
        fi
    else
        echo "DB restoration failed on ${DestinationMachine}" | cowsay
        exit 1
    fi
}

cleanup_on_jenkins () {

    rm -f /tmp/${SourceDatabase}*
}

cleanup_on_source_remote () {

    ansible ${SourceMachine} -m shell -a "rm -rf /tmp/${SourceDatabase}*"
}

cleanup_on_destination_remote () {

    ansible ${DestinationMachine} -m shell -a "rm -rf /tmp/${SourceDatabase}*"
}

# Setting Variable value of db_dump_to_be_downloaded or previous_date_db_dump_to_be_downloaded which will decide which db will be restored on remote machine
if [ ${LiveDB} = "false" ]; then
    if [ -z ${PreviousDumpDate} ];then
        db_dump_to_be_downloaded=`aws s3 ls s3://${SourceMachine}-mysql-backup/${SourceDatabase} | sort | tail -n 1 | awk '{print $NF}'`
        echo "Database which will be restored is ${db_dump_to_be_downloaded}" | cowsay
    else
        previous_date_db_dump_to_be_downloaded=`aws s3 ls s3://${SourceMachine}-mysql-backup/${SourceDatabase}-${PreviousDumpDate} | sort | tail -n 1 | awk '{print $NF}'`
        echo "Database which will be restored is ${previous_date_db_dump_to_be_downloaded}" | cowsay
    fi
fi

mysql_dump_download_on_jenkins () {
    echo "inside mysql_dump_download_on_jenkins"
    if [ -z ${PreviousDumpDate} ];then
        if [ ! -z ${TableName} ] || [ ${OnlyProcedure} = "true" ];then
            echo "Condition 2 (mysql_dump_download_on_jenkins): Downloading dump on Jenkins Server as either table name or procedure is mentioned/selected" | cowsay
            aws s3 cp s3://${SourceMachine}-mysql-backup/${db_dump_to_be_downloaded} /tmp/
        else 
            echo "Condition 3 (mysql_dump_download_on_jenkins): ${message}" | cowsay
            exit 1
        fi
    else
        if [ ! -z ${TableName} ] || [ ${OnlyProcedure} = "true" ];then
            echo "Condition 4 (mysql_dump_download_on_jenkins): Downloading dump on Jenkins Server as either table name or procedure is mentioned/selected" | cowsay
            aws s3 cp s3://${SourceMachine}-mysql-backup/${previous_date_db_dump_to_be_downloaded} /tmp/
        else 
            echo "Condition 5 (mysql_dump_download_on_jenkins): ${message}" | cowsay
            exit 1
        fi
    fi
}

mysql_dump_download_on_remote () {
    echo "inside mysql_dump_download_on_remote"
    if [ -z ${PreviousDumpDate} ];then
        if [ -z ${TableName} ] && [ ${OnlyProcedure} = "false" ];then
            echo "Condition 6 (mysql_dump_download_on_remote): Downloading dump on ${SourceMachine}" | cowsay
            ansible ${DestinationMachine} -m shell -a "aws s3 cp s3://${SourceMachine}-mysql-backup/${db_dump_to_be_downloaded} /tmp/"
        else 
            echo "Condition 7 (mysql_dump_download_on_remote): ${message}" | cowsay
            exit 1
        fi
    else
        if [ -z ${TableName} ] && [ ${OnlyProcedure} = "false" ];then
            echo "Condition 8 (mysql_dump_download_on_remote): Downloading dump on ${SourceMachine}" | cowsay
            ansible ${DestinationMachine} -m shell -a "aws s3 cp s3://${SourceMachine}-mysql-backup/${previous_date_db_dump_to_be_downloaded} /tmp/"
        else 
            echo "Condition 9 (mysql_dump_download_on_remote): ${message}" | cowsay
            exit 1
        fi
    fi
}

post_restore_db_updation () {
        ansible ${DestinationMachine} -m shell -a """mysql -u${mysql_username} -p${mysql_password} -e 'use ${DestinationDatabase}; show tables;' | grep -w user"""
        if [ `echo $?` -eq 0 ];then
            ansible ${DestinationMachine} -m shell -a """mysql -u${mysql_username} -p${mysql_password} -e 'update ${DestinationDatabase}.user set useremail = concat(useremail, \"xy\");'"""
        fi
        ansible ${DestinationMachine} -m shell -a """mysql -u${mysql_username} -p${mysql_password} -e 'use ${DestinationDatabase}; show tables;' | grep -w officialinformation_9"""
        if [ `echo $?` -eq 0 ];then
            ansible ${DestinationMachine} -m shell -a """mysql -u${mysql_username} -p${mysql_password} -e 'update ${DestinationDatabase}.officialinformation_9 set officialemailid = concat(officialemailid , \"xy\");'"""
        fi

}
# This function will restore db on jenkins machine (if TableName is not empty or OnlyProcedure is selected)
restore_db_on_jenkins () {
    echo "inside restore_db_on_jenkins"
    if [ -z ${PreviousDumpDate} ];then
        if [ ! -z ${TableName} ] || [ ${OnlyProcedure} = "true" ];then
            mysql -u${mysql_username} -p${mysql_password} -e "drop database ${SourceDatabase};"
            mysql -u${mysql_username} -p${mysql_password} -e "create database ${SourceDatabase};"
            zcat /tmp/${db_dump_to_be_downloaded} | mysql -u${mysql_username} -p${mysql_password} ${SourceDatabase}
        fi
    else
        if [ ! -z ${TableName} ] || [ ${OnlyProcedure} = "true" ];then
            mysql -u${mysql_username} -p${mysql_password} -e "drop database ${SourceDatabase};"
            mysql -u${mysql_username} -p${mysql_password} -e "create database ${SourceDatabase};"
            zcat /tmp/${previous_date_db_dump_to_be_downloaded} | mysql -u${mysql_username} -p${mysql_password} ${SourceDatabase}
        fi
    fi
}

post_restore_db_on_jenkins () {
    echo "inside post_restore_db_on_jenkins"

    if [ ! -z ${TableName} ];then
        mysqldump -u${mysql_username} -p${mysql_password} ${SourceDatabase} ${TableName} > /tmp/${SourceDatabase}_${TableName}.sql
        gzip /tmp/${SourceDatabase}_${TableName}.sql
        ansible ${DestinationMachine} -m shell -a "mysql -u${mysql_username} -p${mysql_password} -e 'show databases;' | grep ${DestinationDatabase}"
        if [ `echo $?` -eq 0 ]; then
            ansible ${DestinationMachine} -m copy -a "src=/tmp/${SourceDatabase}_${TableName}.sql.gz dest=/tmp/${SourceDatabase}_${TableName}.sql.gz"
            ansible ${DestinationMachine} -m shell -a "zcat /tmp/${SourceDatabase}_${TableName}.sql.gz | mysql -u${mysql_username} -p${mysql_password} ${DestinationDatabase} ${TableName}"
            db_restoration_check
        else 
            echo "Database ${DestinationDatabase} doesn't exists on ${DestinationMachine}. Hence only single table can't be restored" | cowsay
            exit 1
        fi
    elif [ ${OnlyProcedure} = "true" ];then
        mysqldump -u${mysql_username} -p${mysql_password} --routines --no-create-info --no-data --no-create-db --skip-opt ${SourceDatabase} > /tmp/${SourceDatabase}_sp.sql
        gzip /tmp/${SourceDatabase}_sp.sql
        ansible ${DestinationMachine} -m shell -a "mysql -u${mysql_username} -p${mysql_password} -e 'show databases;' | grep ${DestinationDatabase}"
        if [ `echo $?` -eq 0 ]; then
            ansible ${DestinationMachine} -m copy -a "src=/tmp/${SourceDatabase}_sp.sql.gz dest=/tmp/${SourceDatabase}_sp.sql.gz"
            ansible ${DestinationMachine} -m shell -a "zcat /tmp/${SourceDatabase}_sp.sql.gz | mysql -u${mysql_username} -p${mysql_password} ${DestinationDatabase} ${TableName}"
            db_restoration_check
        else 
            echo "Database ${DestinationDatabase} doesn't exists on ${DestinationMachine}. Hence Procedure can't be restored" | cowsay
            exit 1
        fi
    fi
}

# This function will restore db directly on remote server (if TableName is empty and OnlyProcedure is not selected)
restore_db_on_remote () {
    echo "inside restore_db_on_remote"
    if [ -z ${PreviousDumpDate} ];then
        if [ -z ${TableName} ] && [ ${OnlyProcedure} = "false" ];then
            ansible ${DestinationMachine} -m shell -a "mysql -u${mysql_username} -p${mysql_password} -e 'drop database ${DestinationDatabase};'"
            ansible ${DestinationMachine} -m shell -a "mysql -u${mysql_username} -p${mysql_password} -e 'create database ${DestinationDatabase};'"
            ansible ${DestinationMachine} -m shell -a "zcat /tmp/${db_dump_to_be_downloaded} | mysql -u${mysql_username} -p${mysql_password} ${DestinationDatabase}"
            db_restoration_check
            post_restore_db_updation
        fi
    else
        if [ -z ${TableName} ] && [ ${OnlyProcedure} = "false" ];then
            ansible ${DestinationMachine} -m shell -a "mysql -u${mysql_username} -p${mysql_password} -e 'drop database ${DestinationDatabase};'"
            ansible ${DestinationMachine} -m shell -a "mysql -u${mysql_username} -p${mysql_password} -e 'create database ${DestinationDatabase};'"
            ansible ${DestinationMachine} -m shell -a "zcat /tmp/${previous_date_db_dump_to_be_downloaded} | mysql -u${mysql_username} -p${mysql_password} ${DestinationDatabase}"
            db_restoration_check
            post_restore_db_updation
        fi
    fi
}

live_db_mysql_dump () {

    if [ -z ${PreviousDumpDate} ];then
        if [ ${LiveDB} = "true" ]; then
            #if [[ ( ${FullDB} = "true" ) && ( -z ${TableName} && ${OnlyProcedure} = "false" ) ]];then
            if [ ${FullDB} = "true" ] && [ -z ${TableName} ] && [ ${OnlyProcedure} = "false" ]; then
                echo "restoring live full db" | cowsay
                cleanup_on_source_remote
                ansible ${SourceMachine} -m shell -a "mysqldump -u${mysql_username} -p${mysql_password} ${SourceDatabase} --routines --single-transaction --quick > /tmp/${SourceDatabase}.sql"
                ansible ${SourceMachine} -m shell -a "gzip /tmp/${SourceDatabase}.sql"
                ansible ${SourceMachine} -m fetch -a "src=/tmp/${SourceDatabase}.sql.gz dest=/tmp/${SourceDatabase}.sql.gz"
                if [ `echo $?` -eq 0 ]; then
                    cleanup_on_destination_remote
                    ansible ${DestinationMachine} -m copy -a "src=/tmp/${SourceDatabase}.sql.gz dest=/tmp/${SourceDatabase}.sql.gz"
                    ansible ${DestinationMachine} -m shell -a "mysql -u${mysql_username} -p${mysql_password} -e 'drop database ${DestinationDatabase};'"
                    ansible ${DestinationMachine} -m shell -a "mysql -u${mysql_username} -p${mysql_password} -e 'create database ${DestinationDatabase};'"
                    ansible ${DestinationMachine} -m shell -a "zcat /tmp/${SourceDatabase}.sql.gz/${SourceDatabase}.sql.gz/${SourceMachine}/tmp/${SourceDatabase}.sql.gz | mysql -u${mysql_username} -p${mysql_password} ${DestinationDatabase}"
                    db_restoration_check
                    post_restore_db_updation
                    cleanup_on_destination_remote
                fi
            elif [ ${FullDB} = "false" ] && [ ! -z ${TableName} ] && [ ${OnlyProcedure} = "false" ]; then
                echo "Restoring single table" | cowsay
                cleanup_on_source_remote
                ansible ${SourceMachine} -m shell -a "mysqldump -u${mysql_username} -p${mysql_password} ${SourceDatabase} ${TableName} > /tmp/${SourceDatabase}_${TableName}.sql"
                ansible ${SourceMachine} -m shell -a "gzip /tmp/${SourceDatabase}_${TableName}.sql"
                ansible ${SourceMachine} -m fetch -a "src=/tmp/${SourceDatabase}_${TableName}.sql.gz dest=/tmp/${SourceDatabase}_${TableName}.sql.gz"
                if [ `echo $?` -eq 0 ]; then
                    cleanup_on_destination_remote
                    ansible ${DestinationMachine} -m copy -a "src=/tmp/${SourceDatabase}_${TableName}.sql.gz dest=/tmp/${SourceDatabase}_${TableName}.sql.gz"
                    ansible ${DestinationMachine} -m shell -a "zcat /tmp/${SourceDatabase}_${TableName}.sql.gz/${SourceDatabase}_${TableName}.sql.gz/${SourceMachine}/tmp/${SourceDatabase}_${TableName}.sql.gz | mysql -u${mysql_username} -p${mysql_password} ${DestinationDatabase}"
                    db_restoration_check
                    cleanup_on_destination_remote
                fi

            elif [ ${FullDB} = "false" ] && [ -z ${TableName} ] && [ ${OnlyProcedure} = "true" ]; then
                echo "restoring only procedures" | cowsay
                cleanup_on_source_remote
                ansible ${SourceMachine} -m shell -a "mysqldump -u${mysql_username} -p${mysql_password} --routines --no-create-info --no-data --no-create-db --skip-opt ${SourceDatabase} > /tmp/${SourceDatabase}_sp.sql"
                ansible ${SourceMachine} -m shell -a "gzip /tmp/${SourceDatabase}_sp.sql"
                ansible ${SourceMachine} -m fetch -a "src=/tmp/${SourceDatabase}_sp.sql.gz dest=/tmp/${SourceDatabase}_sp.sql.gz"
                if [ `echo $?` -eq 0 ]; then
                    cleanup_on_destination_remote
                    ansible ${DestinationMachine} -m copy -a "src=/tmp/${SourceDatabase}_sp.sql.gz dest=/tmp/${SourceDatabase}_sp.sql.gz"
                    ansible ${DestinationMachine} -m shell -a "zcat /tmp/${SourceDatabase}_sp.sql.gz/${SourceDatabase}_sp.sql.gz/${SourceMachine}/tmp/${SourceDatabase}_sp.sql.gz | mysql -u${mysql_username} -p${mysql_password} ${DestinationDatabase}"
                    db_restoration_check
                    cleanup_on_destination_remote
                fi

            else    
                echo "Please do not mention or select PreviousDumpDate, TableName or OnlyProcedure - When seleted Full DB" | cowsay
                exit 1
            fi
        fi
    else
        echo "Please do not mention or select PreviousDumpDate, TableName or OnlyProcedure - When seleted Full DB" | cowsay
        exit 1
    fi
}


if [ ${LiveDB} = "false" ]; then

    if [[ ( ${FullDB} = "true" ) && ( ! -z ${TableName} || ${OnlyProcedure} = "true" ) ]];then

        echo "Condition 10: ${message}" | cowsay
        exit 1

    elif [ ${FullDB} = "true" ] || [ ! -z ${TableName} ] && [ ${OnlyProcedure} = "true" ];then

        echo "Condition 11: ${message}" | cowsay
        exit 1
    
    elif [[ ( ${FullDB} = "false" ) && ( -z ${TableName} && ${OnlyProcedure} = "false" ) ]];then
        
        echo "Condition 12: ${message}" | cowsay
        exit 1
    

    elif [ ${FullDB} = "true" ] && [ -z ${PreviousDumpDate} ];then
        cleanup_on_destination_remote
        mysql_dump_download_on_remote
        restore_db_on_remote
        cleanup_on_destination_remote

    elif [ ${FullDB} = "true" ] && [ ! -z ${PreviousDumpDate} ];then
        cleanup_on_destination_remote
        mysql_dump_download_on_remote
        restore_db_on_remote
        cleanup_on_destination_remote

    elif [ ${FullDB} = "false" ] && [ -z ${PreviousDumpDate} ];then
        cleanup_on_jenkins
        cleanup_on_destination_remote
        mysql_dump_download_on_jenkins
        restore_db_on_jenkins
        post_restore_db_on_jenkins
        cleanup_on_jenkins
        cleanup_on_destination_remote
        

    elif [ ${FullDB} = "false" ] && [ ! -z ${PreviousDumpDate} ];then
        cleanup_on_jenkins
        cleanup_on_destination_remote
        mysql_dump_download_on_jenkins
        restore_db_on_jenkins
        post_restore_db_on_jenkins
        cleanup_on_jenkins
        cleanup_on_destination_remote
        
    fi
else 
    live_db_mysql_dump
fi
    
