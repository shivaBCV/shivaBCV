#!/bin/bash
# Stop on any errors
#set -e

if [ -z ${DomainName} ] && [ "${All_Machines}" = "false" ]; then
	echo "ERROR: seems you are confused - Either mention Domain Name or select All machines"
    exit 1;
elif ! [ -z ${DomainName} ] && ! [ "${All_Machines}" = "false" ]; then
	echo "ERROR: seems you are confused - Either mention Domain Name or select All machines not both"
	exit 1;
fi

echo "Getting devops machines list"
aws ec2 describe-instances --filters "Name=instance-state-name,Values=running" "Name=tag:machine,Values=devops" --query 'Reservations[*].Instances[*].[PrivateIpAddress]' | grep -Ev '(\[|\])' | awk 'BEGIN {FS="\""} {print $2}' > devops-machines.txt

echo "Getting all Running EC2 machines list"
aws ec2 describe-instances --filters "Name=instance-state-name,Values=running" --query 'Reservations[*].Instances[*].[PrivateIpAddress]' | grep -Ev '(\[|\])' | awk 'BEGIN {FS="\""} {print $2}' > running-machines.txt

echo "Finding EC2 machines where users needs to be created"
cat running-machines.txt devops-machines.txt | sort | uniq -c | awk '{if ($1==1) print $2}' > ec2-machines.txt

echo "Finding onpremise machines where users needs to be created"
cat ${WORKSPACE}/Files/onpremise-machines.txt | grep -Ev "(^#|^$)" > onpremise-machines.txt

echo "Combining ec2 machines and onpremise machines"
cat ec2-machines.txt onpremise-machines.txt > final-machines.txt

if ! [ -z "${DomainName}" ]; then
	if [ ${action} = "add" ]; then
    	echo " ***************** Adding user on ${machines} *****************"
        echo "Adding group - ${username}"
        ansible ${DomainName} -m shell -a "sudo groupadd ${username}"
        status=`echo $?`
        echo $status
        if [ $status -eq 0 ]; then
            echo "creating user - ${username}"
            ansible ${DomainName} -m shell -a "sudo useradd -s /bin/bash -m -d /home/${username}  -g ${username} ${username}"
            echo "creating .ssh directory under /home/${username}"
            ansible ${DomainName} -m shell -a "sudo mkdir -p /home/${username}/.ssh"
            echo "changin ownership of /home/${username}/.ssh to ${username}:${username}"
            ansible ${DomainName} -m shell -a "sudo chown ${username}:${username} /home/${username}/.ssh"
            echo "changing permission of /home/$USERNAME/.ssh to 777"
            ansible ${DomainName} -m shell -a "sudo chmod 777 /home/${username}/.ssh"
            echo "copying ${username}.pub to /home/${username}/.ssh/authorized_keys"
            ansible ${DomainName} -m copy -a "src=${WORKSPACE}/Files/users_public_keys/${username}.pub dest=/home/${username}/.ssh/authorized_keys"
            echo "changing permission of /home/${username}/.ssh to 700"
            ansible ${DomainName} -m shell -a "sudo chmod 700 /home/${username}/.ssh"
            echo "changing permission of /home/${username}/.ssh/authorized_keys to 600"
            ansible ${DomainName} -m shell -a "sudo chmod 600 /home/${username}/.ssh/authorized_keys"
            echo "chaning ownership of /home/${username}/.ssh/authorized_keys to ${username}:${username}"
            ansible ${DomainName} -m shell -a "sudo chown ${username}:${username} /home/${username}/.ssh/authorized_keys"
            echo "adding ${username} user to ubuntu group"
            ansible ${DomainName} -m shell -a "sudo usermod -a -G ubuntu ${username}"
        else 
            echo "${username} already available on $machines"
        fi
    elif [ ${action} = "remove" ]; then
        echo "***************** removing user from ${machines} *****************"
        echo "removing user ${username}"
        ansible ${DomainName} -m shell -a "sudo userdel -r ${username}"
    fi
elif [ ${All_Machines} = "true" ]; then
	if [ ${action} = "add" ]; then
    	for machines in `cat final-machines.txt`
            do  
                echo " ***************** Adding user on ${machines} *****************"
                echo "Adding group - ${username}"
                ansible $machines -m shell -a "sudo groupadd ${username}"
                status=`echo $?`
                echo $status
                if [ $status -eq 0 ]; then
                    echo "creating user - ${username}"
                    ansible $machines -m shell -a "sudo useradd -s /bin/bash -m -d /home/${username}  -g ${username} ${username}"
                    echo "creating .ssh directory under /home/${username}"
                    ansible $machines -m shell -a "sudo mkdir -p /home/${username}/.ssh"
                    echo "changin ownership of /home/${username}/.ssh to ${username}:${username}"
                    ansible $machines -m shell -a "sudo chown ${username}:${username} /home/${username}/.ssh"
                    echo "changing permission of /home/$USERNAME/.ssh to 777"
                    ansible $machines -m shell -a "sudo chmod 777 /home/${username}/.ssh"
                    echo "copying ${username}.pub to /home/${username}/.ssh/authorized_keys"
                    ansible $machines -m copy -a "src=${WORKSPACE}/Files/users_public_keys/${username}.pub dest=/home/${username}/.ssh/authorized_keys"
                    echo "changing permission of /home/${username}/.ssh to 700"
                    ansible $machines -m shell -a "sudo chmod 700 /home/${username}/.ssh"
                    echo "changing permission of /home/${username}/.ssh/authorized_keys to 600"
                    ansible $machines -m shell -a "sudo chmod 600 /home/${username}/.ssh/authorized_keys"
                    echo "chaning ownership of /home/${username}/.ssh/authorized_keys to ${username}:${username}"
                    ansible $machines -m shell -a "sudo chown ${username}:${username} /home/${username}/.ssh/authorized_keys"
                    echo "adding ${username} user to ubuntu group"
                    ansible $machines -m shell -a "sudo usermod -a -G ubuntu ${username}"
                else 
                    echo "${username} already available on $machines"
                fi
            done
    elif [ ${action} = "remove" ]; then
    	for machines in `cat final-machines.txt`
            do
                echo "***************** removing user from ${machines} *****************"
                echo "removing user ${username}"
                ansible $machines -m shell -a "sudo userdel -f -r ${username}"
            done
    fi
fi